# Thành viên 3 — Baseline & Decision Tree

Phần việc trong bài tập nhóm: **dự đoán sinh viên có qua môn hay không** (`passed`:
1 = Đậu, 0 = Rớt) từ 4 đặc trưng: giờ tự học, tỷ lệ chuyên cần, điểm giữa kỳ,
số bài tập đã nộp.

Nhiệm vụ được giao:

1. Code tách tập dữ liệu thành Train/Test.
2. Xây dựng mô hình Baseline (luôn đoán lớp nhiều nhất).
3. Huấn luyện mô hình Decision Tree và xuất sơ đồ cây quyết định để trực quan hóa.

---

## 1. Kết quả chính (tập Test, 79 mẫu)

| Mô hình | Accuracy | Precision | Recall | F1 | F1-macro | ROC-AUC |
|---|---|---|---|---|---|---|
| Baseline (Majority) | 0.671 | 0.671 | 1.000 | 0.803 | 0.402 | 0.500 |
| Decision Tree (không giới hạn) | 0.785 | 0.891 | 0.774 | 0.828 | 0.770 | 0.813 |
| **Decision Tree (đã tinh chỉnh)** | **0.797** | **0.911** | 0.774 | **0.837** | **0.785** | **0.908** |

*Precision / Recall / F1 trong bảng tính cho lớp Đậu.*

Decision Tree vượt Baseline **12.7 điểm %** về Accuracy. Khác biệt quan trọng hơn
nằm ở lớp thiểu số: Baseline bắt được **0/26** sinh viên rớt, cây bắt được
**22/26** (recall 0.846).

Mô hình cuối: `DecisionTreeClassifier(criterion="entropy", max_depth=4,
min_samples_leaf=20, random_state=42)` — cây 4 tầng, 8 lá.

Độ quan trọng đặc trưng: Điểm giữa kỳ 0.89 · Tỷ lệ chuyên cần 0.09 ·
Giờ tự học 0.02 · Số bài tập đã nộp 0.00.

---

## 2. Cấu trúc thư mục

```
thanh_vien_3_baseline_decision_tree/
├── README.md                                    # file này
├── BAO_CAO_THANH_VIEN_3.md                      # phần viết để ghép vào báo cáo nhóm
├── thanh_vien_3_baseline_decision_tree.ipynb    # notebook chính (code + kết quả đã chạy)
├── thanh_vien_3_baseline_decision_tree.py       # bản script, chạy bằng dòng lệnh
├── student_data.csv                             # dữ liệu gốc (395 sinh viên)
├── requirements.txt                             # thư viện cần cài
├── .gitignore
└── outputs_thanh_vien_3/                        # kết quả sinh ra khi chạy
    ├── so_do_cay_graphviz.png / .svg            # SƠ ĐỒ CÂY — bản nét nhất, dùng cho báo cáo/slide
    ├── so_do_cay_quyet_dinh.png                 # sơ đồ cây vẽ bằng matplotlib
    ├── so_do_cay_quyet_dinh.dot                 # file Graphviz nguồn
    ├── luat_cay_quyet_dinh.txt                  # các luật của cây dạng văn bản
    ├── ma_tran_nham_lan.png                     # confusion matrix của 3 mô hình
    ├── so_sanh_chi_so.png                       # biểu đồ cột so sánh Baseline vs Decision Tree
    ├── do_sau_vs_accuracy.png                   # minh họa overfitting theo max_depth
    ├── do_quan_trong_dac_trung.png              # feature importance
    ├── bang_so_sanh_mo_hinh.csv                 # bảng kết quả dạng số
    ├── grid_search_results.csv                  # toàn bộ kết quả GridSearchCV
    ├── tom_tat_ket_qua.json                     # tóm tắt để ghép vào báo cáo chung
    ├── train.csv                                # BỘ CHIA DÙNG CHUNG — 316 mẫu
    └── test.csv                                 # BỘ CHIA DÙNG CHUNG — 79 mẫu
```

---

## 3. Cách chạy

```bash
pip install -r requirements.txt
```

Chạy notebook (khuyến nghị — có sẵn giải thích và kết quả):

```bash
jupyter notebook thanh_vien_3_baseline_decision_tree.ipynb
```

Hoặc chạy script, kết quả ghi vào `outputs_thanh_vien_3/`:

```bash
python thanh_vien_3_baseline_decision_tree.py
```

Ghi chú:

- Notebook đã **nhúng sẵn dữ liệu** (gzip + base64) nên chạy được cả khi thiếu
  `student_data.csv`. Script thì cần file CSV đặt cùng thư mục.
- Phần render Graphviz là tùy chọn. Nếu máy chưa cài Graphviz, chương trình vẫn
  chạy bình thường và lưu file `.dot` (xem online tại
  <https://dreampuf.github.io/GraphvizOnline>). Cài Graphviz:
  `apt install graphviz` (Ubuntu) / `brew install graphviz` (macOS) /
  tải tại <https://graphviz.org/download/> (Windows).

---

## 4. Lưu ý cho các thành viên khác trong nhóm

**Dùng chung bộ chia dữ liệu.** File `outputs_thanh_vien_3/train.csv` và
`test.csv` được tạo với `train_test_split(test_size=0.2, stratify=y,
random_state=42)`. Các mô hình khác (Logistic Regression, KNN, Random Forest…)
nên đọc trực tiếp hai file này thay vì tự chia lại, nếu không bảng so sánh cuối
cùng sẽ không công bằng:

```python
import pandas as pd

train = pd.read_csv("outputs_thanh_vien_3/train.csv")
test = pd.read_csv("outputs_thanh_vien_3/test.csv")
X_train, y_train = train.drop(columns="passed"), train["passed"]
X_test, y_test = test.drop(columns="passed"), test["passed"]
```

**Chỉ số nên báo cáo.** Dữ liệu lệch lớp (67.1% Đậu), nên đừng chỉ nhìn Accuracy —
Baseline đạt 0.671 mà không dự đoán đúng sinh viên rớt nào. Hãy báo cáo kèm
**F1-macro** và **ROC-AUC**.

**Tập Test chỉ dùng một lần** ở bước đánh giá cuối. Việc chọn siêu tham số làm
bằng cross-validation trên tập Train.
