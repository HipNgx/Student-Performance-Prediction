# -*- coding: utf-8 -*-
"""
THÀNH VIÊN 3 — BASELINE & DECISION TREE
=======================================
Bài toán : Dự đoán sinh viên có qua môn hay không (cột `passed`: 1 = đậu, 0 = rớt)
Dữ liệu  : student_data.csv (395 dòng, 4 đặc trưng số + 1 nhãn)

Nội dung:
  1. Đọc & kiểm tra dữ liệu
  2. Tách tập Train/Test (80/20, stratified)
  3. Mô hình Baseline — luôn đoán lớp chiếm đa số
  4. Huấn luyện Decision Tree (chọn siêu tham số bằng Cross-Validation trên tập Train)
  5. Đánh giá & so sánh với Baseline
  6. Xuất sơ đồ cây quyết định (PNG + text + DOT/Graphviz)

Chạy:  python thanh_vien_3_baseline_decision_tree.py
       (có thể chạy từng cell "# %%" trong VS Code / Jupyter)
Thư viện: pandas, numpy, scikit-learn, matplotlib
"""

# %% ============================================================
# 0. IMPORT & CẤU HÌNH
# ===============================================================
import json
import shutil
import subprocess
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # vẽ không cần màn hình; xóa dòng này nếu chạy trong Jupyter
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.tree import DecisionTreeClassifier, export_graphviz, export_text, plot_tree

DATA_PATH = Path("student_data.csv")        # đổi đường dẫn nếu cần
OUTPUT_DIR = Path("outputs_thanh_vien_3")
OUTPUT_DIR.mkdir(exist_ok=True)

RANDOM_STATE = 42     # cố định để cả nhóm tái lập được kết quả giống nhau
TEST_SIZE = 0.2
TARGET = "passed"
CLASS_NAMES = ["Rớt (0)", "Đậu (1)"]

# Tên tiếng Việt để sơ đồ cây dễ đọc khi đưa vào báo cáo
FEATURE_LABELS = {
    "study_hours": "Giờ tự học",
    "attendance_rate": "Tỷ lệ chuyên cần (%)",
    "midterm_score": "Điểm giữa kỳ",
    "assignments_submitted": "Số bài tập đã nộp",
}


# %% ============================================================
# 1. ĐỌC & KIỂM TRA DỮ LIỆU
# ===============================================================
df = pd.read_csv(DATA_PATH)

print("=" * 65)
print("1. TỔNG QUAN DỮ LIỆU")
print("=" * 65)
print(f"Kích thước        : {df.shape[0]} dòng x {df.shape[1]} cột")
print(f"Giá trị thiếu     : {int(df.isna().sum().sum())}")
print(f"Dòng trùng lặp    : {int(df.duplicated().sum())} "
      "(giữ lại — đặc trưng đã rời rạc hóa nên nhiều SV có hồ sơ giống nhau)")
print("\nPhân bố nhãn:")
dist = df[TARGET].value_counts().sort_index()
for label, cnt in dist.items():
    print(f"  {CLASS_NAMES[label]:<9}: {cnt:>4} ({cnt / len(df):.1%})")

X = df.drop(columns=TARGET)
y = df[TARGET]
FEATURES = X.columns.tolist()


# %% ============================================================
# 2. TÁCH TẬP TRAIN / TEST
# ===============================================================
# stratify=y  -> giữ nguyên tỷ lệ Đậu/Rớt (~67/33) ở cả 2 tập.
#               Dữ liệu lệch lớp nên nếu không stratify, tập test nhỏ (79 mẫu)
#               có thể bị lệch tỷ lệ và làm kết quả đánh giá thiếu tin cậy.
# Tập Test chỉ dùng MỘT LẦN ở bước đánh giá cuối -> không dùng để chọn tham số.
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=TEST_SIZE,
    stratify=y,
    random_state=RANDOM_STATE,
)

print("\n" + "=" * 65)
print("2. TÁCH TRAIN / TEST")
print("=" * 65)
print(f"Train: {X_train.shape[0]} mẫu | tỷ lệ Đậu = {y_train.mean():.1%}")
print(f"Test : {X_test.shape[0]} mẫu | tỷ lệ Đậu = {y_test.mean():.1%}")

# Lưu lại để các thành viên khác dùng CHUNG một cách chia (so sánh công bằng)
X_train.assign(**{TARGET: y_train}).to_csv(OUTPUT_DIR / "train.csv", index=False)
X_test.assign(**{TARGET: y_test}).to_csv(OUTPUT_DIR / "test.csv", index=False)


# %% ============================================================
# HÀM TIỆN ÍCH ĐÁNH GIÁ
# ===============================================================
def evaluate(name, model, X_eval, y_eval):
    """Tính các chỉ số phân loại chính và in báo cáo chi tiết."""
    y_pred = model.predict(X_eval)
    y_proba = model.predict_proba(X_eval)[:, 1]

    metrics = {
        "Mô hình": name,
        "Accuracy": accuracy_score(y_eval, y_pred),
        "Precision": precision_score(y_eval, y_pred, zero_division=0),
        "Recall": recall_score(y_eval, y_pred, zero_division=0),
        "F1": f1_score(y_eval, y_pred, zero_division=0),
        "F1-macro": f1_score(y_eval, y_pred, average="macro", zero_division=0),
        # Baseline cho xác suất hằng số -> ROC-AUC = 0.5 (không phân biệt được gì)
        "ROC-AUC": roc_auc_score(y_eval, y_proba),
    }

    print(f"\n--- {name} ---")
    print(classification_report(y_eval, y_pred, target_names=CLASS_NAMES,
                                digits=3, zero_division=0))
    return metrics, y_pred


# %% ============================================================
# 3. MÔ HÌNH BASELINE — LUÔN ĐOÁN LỚP NHIỀU NHẤT
# ===============================================================
# Ý nghĩa: đây là "mức sàn". Mọi mô hình học máy phải VƯỢT mức này
# thì mới chứng tỏ đã học được điều gì đó từ đặc trưng.
print("\n" + "=" * 65)
print("3. BASELINE (Majority Class)")
print("=" * 65)

# Cách 1: tự cài đặt để thấy rõ bản chất
majority_class = y_train.mode()[0]           # lớp nhiều nhất TRONG TẬP TRAIN
manual_pred = np.full(len(y_test), majority_class)
print(f"Lớp đa số trên tập Train: {majority_class} -> {CLASS_NAMES[majority_class]}")
print(f"Accuracy (tự cài đặt)   : {accuracy_score(y_test, manual_pred):.3f}")

# Cách 2: dùng DummyClassifier của scikit-learn (chuẩn, có predict_proba)
baseline = DummyClassifier(strategy="most_frequent")
baseline.fit(X_train, y_train)
baseline_metrics, baseline_pred = evaluate("Baseline (Majority)", baseline, X_test, y_test)

assert (baseline_pred == manual_pred).all(), "Hai cách cài đặt Baseline phải cho cùng kết quả"


# %% ============================================================
# 4. HUẤN LUYỆN DECISION TREE
# ===============================================================
print("\n" + "=" * 65)
print("4. DECISION TREE")
print("=" * 65)

# 4a. Cây "mặc định" (không giới hạn) — để minh họa hiện tượng overfitting
tree_full = DecisionTreeClassifier(random_state=RANDOM_STATE)
tree_full.fit(X_train, y_train)
print(f"Cây không giới hạn: độ sâu = {tree_full.get_depth()}, "
      f"số lá = {tree_full.get_n_leaves()}")
print(f"  Accuracy Train = {tree_full.score(X_train, y_train):.3f} | "
      f"Test = {tree_full.score(X_test, y_test):.3f}  <- chênh lệch lớn = overfitting")

# 4b. Chọn siêu tham số bằng GridSearch + 5-fold Stratified CV CHỈ TRÊN TẬP TRAIN
#     - max_depth       : giới hạn độ sâu -> cây gọn, dễ giải thích, ít overfit
#     - min_samples_leaf: mỗi lá phải có đủ mẫu -> quy tắc đáng tin hơn
#     - criterion       : gini hoặc entropy (information gain)
#     - class_weight    : 'balanced' giúp lớp "Rớt" (thiểu số) không bị bỏ qua
#     Tiêu chí chọn = F1-macro: coi trọng CẢ HAI lớp, tránh chọn nhầm một
#     mô hình chỉ "ăn theo" lớp đa số giống Baseline.
param_grid = {
    "max_depth": [2, 3, 4, 5, 6, 8],
    "min_samples_leaf": [1, 5, 10, 20],
    "criterion": ["gini", "entropy"],
    "class_weight": [None, "balanced"],
}


def one_std_rule(cv_results):
    """Quy tắc "1 độ lệch chuẩn" (one-standard-error rule).

    Chọn cấu hình ĐƠN GIẢN NHẤT có điểm CV không kém cấu hình tốt nhất quá
    1 độ lệch chuẩn. Lý do: với 316 mẫu train, chênh lệch vài phần nghìn giữa
    các cấu hình chỉ là nhiễu; cây nông hơn thì ổn định hơn và sơ đồ
    dễ đọc hơn nhiều khi đưa vào báo cáo.
    Độ "đơn giản": max_depth nhỏ hơn, rồi min_samples_leaf lớn hơn.
    """
    res = pd.DataFrame(cv_results)
    best = res["rank_test_score"].idxmin()
    threshold = res.loc[best, "mean_test_score"] - res.loc[best, "std_test_score"]
    candidates = res[res["mean_test_score"] >= threshold].copy()
    candidates["_depth"] = candidates["param_max_depth"].astype(int)
    candidates["_leaf"] = candidates["param_min_samples_leaf"].astype(int)
    candidates = candidates.sort_values(
        ["_depth", "_leaf", "rank_test_score"], ascending=[True, False, True])
    return int(candidates.index[0])


cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
grid = GridSearchCV(
    DecisionTreeClassifier(random_state=RANDOM_STATE),
    param_grid=param_grid,
    scoring="f1_macro",
    cv=cv,
    n_jobs=-1,
    refit=one_std_rule,   # refit cây được chọn trên TOÀN BỘ tập Train
)
grid.fit(X_train, y_train)

res = pd.DataFrame(grid.cv_results_)
top = res["rank_test_score"].idxmin()
chosen = grid.best_index_
print(f"\nCấu hình điểm CV cao nhất : {res.loc[top, 'params']}")
print(f"  F1-macro CV = {res.loc[top, 'mean_test_score']:.3f} "
      f"± {res.loc[top, 'std_test_score']:.3f}")
print(f"Cấu hình được chọn (1-SD) : {res.loc[chosen, 'params']}")
print(f"  F1-macro CV = {res.loc[chosen, 'mean_test_score']:.3f} "
      f"± {res.loc[chosen, 'std_test_score']:.3f}")

best_tree = grid.best_estimator_
cv_score_chosen = float(res.loc[chosen, "mean_test_score"])
print(f"Cây được chọn: độ sâu = {best_tree.get_depth()}, số lá = {best_tree.get_n_leaves()}")

# Lưu kết quả grid search để đưa vào phụ lục báo cáo
cv_results = (pd.DataFrame(grid.cv_results_)
              [["params", "mean_test_score", "std_test_score", "rank_test_score"]]
              .sort_values("rank_test_score"))
cv_results.to_csv(OUTPUT_DIR / "grid_search_results.csv", index=False)


# %% ============================================================
# 5. ĐÁNH GIÁ & SO SÁNH TRÊN TẬP TEST
# ===============================================================
print("\n" + "=" * 65)
print("5. ĐÁNH GIÁ TRÊN TẬP TEST")
print("=" * 65)

full_metrics, full_pred = evaluate("Decision Tree (không giới hạn)", tree_full, X_test, y_test)
best_metrics, best_pred = evaluate("Decision Tree (đã tinh chỉnh)", best_tree, X_test, y_test)

comparison = pd.DataFrame([baseline_metrics, full_metrics, best_metrics]).set_index("Mô hình")
print("\nBẢNG SO SÁNH")
print(comparison.round(3).to_string())
comparison.round(4).to_csv(OUTPUT_DIR / "bang_so_sanh_mo_hinh.csv")

gain = best_metrics["Accuracy"] - baseline_metrics["Accuracy"]
print(f"\nDecision Tree tinh chỉnh vượt Baseline {gain * 100:+.1f} điểm % về Accuracy, "
      f"F1-macro từ {baseline_metrics['F1-macro']:.3f} lên {best_metrics['F1-macro']:.3f}.")

# 5a. Ma trận nhầm lẫn cho 3 mô hình
fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
for ax, (title, pred) in zip(axes, [
    ("Baseline (Majority)", baseline_pred),
    ("Decision Tree (không giới hạn)", full_pred),
    ("Decision Tree (đã tinh chỉnh)", best_pred),
]):
    ConfusionMatrixDisplay(confusion_matrix(y_test, pred),
                           display_labels=CLASS_NAMES).plot(ax=ax, cmap="Blues", colorbar=False)
    ax.set_title(f"{title}\nAccuracy = {accuracy_score(y_test, pred):.3f}")
    ax.set_xlabel("Dự đoán")
    ax.set_ylabel("Thực tế")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "ma_tran_nham_lan.png", dpi=150)
plt.close()

# 5b. Biểu đồ so sánh chỉ số
ax = comparison[["Accuracy", "F1", "F1-macro", "ROC-AUC"]].T.plot(
    kind="bar", figsize=(10, 5), rot=0, color=["#9e9e9e", "#ef9a9a", "#42a5f5"])
ax.axhline(baseline_metrics["Accuracy"], ls="--", c="gray", lw=1)
ax.set_ylim(0, 1.05)
ax.set_title("So sánh Baseline và Decision Tree trên tập Test")
ax.set_ylabel("Giá trị")
for container in ax.containers:
    ax.bar_label(container, fmt="%.2f", fontsize=8)
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.08), ncol=3, frameon=False)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "so_sanh_chi_so.png", dpi=150)
plt.close()

# 5c. Độ quan trọng của đặc trưng (Gini importance)
importance = (pd.Series(best_tree.feature_importances_,
                        index=[FEATURE_LABELS[f] for f in FEATURES])
              .sort_values())
print("\nĐộ quan trọng đặc trưng:")
print(importance.sort_values(ascending=False).round(3).to_string())
ax = importance.plot(kind="barh", figsize=(8, 4), color="#42a5f5")
ax.set_title("Độ quan trọng đặc trưng — Decision Tree tinh chỉnh")
ax.set_xlabel("Feature importance (giảm impurity)")
for i, v in enumerate(importance):
    ax.text(v + 0.005, i, f"{v:.2f}", va="center")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "do_quan_trong_dac_trung.png", dpi=150)
plt.close()

# 5d. Ảnh hưởng của độ sâu cây tới Train/Test (minh họa overfitting)
depths = range(1, tree_full.get_depth() + 1)
train_acc, test_acc = [], []
for d in depths:
    m = DecisionTreeClassifier(max_depth=d, random_state=RANDOM_STATE).fit(X_train, y_train)
    train_acc.append(m.score(X_train, y_train))
    test_acc.append(m.score(X_test, y_test))
plt.figure(figsize=(8, 4.5))
plt.plot(depths, train_acc, "o-", label="Train")
plt.plot(depths, test_acc, "s-", label="Test")
plt.axhline(baseline_metrics["Accuracy"], ls="--", c="gray", label="Baseline")
plt.xlabel("max_depth")
plt.ylabel("Accuracy")
plt.title("Độ sâu cây và hiện tượng overfitting")
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "do_sau_vs_accuracy.png", dpi=150)
plt.close()


# %% ============================================================
# 6. XUẤT SƠ ĐỒ CÂY QUYẾT ĐỊNH
# ===============================================================
print("\n" + "=" * 65)
print("6. XUẤT SƠ ĐỒ CÂY")
print("=" * 65)
viet_feature_names = [FEATURE_LABELS[f] for f in FEATURES]

# 6a. Ảnh PNG bằng matplotlib (không cần cài thêm gì)
n_leaves = best_tree.get_n_leaves()
fig_w = max(16, n_leaves * 2.2)
fig_h = max(8, best_tree.get_depth() * 2.4)
fig, ax = plt.subplots(figsize=(fig_w, fig_h))
plot_tree(
    best_tree,
    feature_names=viet_feature_names,
    class_names=CLASS_NAMES,
    filled=True,        # tô màu theo lớp: cam = Rớt, xanh = Đậu; càng đậm càng "thuần"
    rounded=True,
    proportion=False,   # hiển thị số mẫu thật thay vì tỷ lệ
    impurity=True,
    fontsize=10,
    ax=ax,
)
ax.set_title(
    f"Cây quyết định dự đoán Đậu/Rớt — max_depth={best_tree.get_depth()}, "
    f"{n_leaves} lá, Accuracy Test={best_metrics['Accuracy']:.3f}",
    fontsize=14,
)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "so_do_cay_quyet_dinh.png", dpi=150, bbox_inches="tight")
plt.close()
print("Đã lưu: so_do_cay_quyet_dinh.png")

# 6b. Luật dạng văn bản — tiện dán vào báo cáo / thuyết trình
rules = export_text(best_tree, feature_names=viet_feature_names,
                    class_names=CLASS_NAMES, show_weights=True)
(OUTPUT_DIR / "luat_cay_quyet_dinh.txt").write_text(rules, encoding="utf-8")
print("Đã lưu: luat_cay_quyet_dinh.txt\n")
print(rules)

# 6c. File DOT (Graphviz) — ảnh nét hơn, có thể chỉnh sửa; render nếu máy có `dot`
dot_path = OUTPUT_DIR / "so_do_cay_quyet_dinh.dot"
export_graphviz(
    best_tree,
    out_file=str(dot_path),
    feature_names=viet_feature_names,
    class_names=CLASS_NAMES,
    filled=True,
    rounded=True,
    special_characters=True,
)
# Thêm font hỗ trợ tiếng Việt cho Graphviz
dot_src = dot_path.read_text(encoding="utf-8").replace(
    "node [", 'node [fontname="DejaVu Sans", ', 1
).replace("edge [", 'edge [fontname="DejaVu Sans", ', 1)
dot_path.write_text(dot_src, encoding="utf-8")

if shutil.which("dot"):
    subprocess.run(["dot", "-Tpng", "-Gdpi=150", str(dot_path),
                    "-o", str(OUTPUT_DIR / "so_do_cay_graphviz.png")], check=True)
    subprocess.run(["dot", "-Tsvg", str(dot_path),
                    "-o", str(OUTPUT_DIR / "so_do_cay_graphviz.svg")], check=True)
    print("Đã render Graphviz: so_do_cay_graphviz.png / .svg")
else:
    print("Không tìm thấy Graphviz -> chỉ lưu file .dot "
          "(xem online tại https://dreampuf.github.io/GraphvizOnline)")


# %% ============================================================
# 7. LƯU TÓM TẮT CHO NHÓM
# ===============================================================
summary = {
    "split": {"test_size": TEST_SIZE, "stratify": True, "random_state": RANDOM_STATE,
              "n_train": int(len(X_train)), "n_test": int(len(X_test))},
    "baseline": {"majority_class": int(majority_class),
                 **{k: round(v, 4) for k, v in baseline_metrics.items() if k != "Mô hình"}},
    "decision_tree": {"best_params": grid.best_params_,
                      "cv_f1_macro": round(cv_score_chosen, 4),
                      "depth": int(best_tree.get_depth()),
                      "n_leaves": int(n_leaves),
                      **{k: round(v, 4) for k, v in best_metrics.items() if k != "Mô hình"}},
    "feature_importance": importance.sort_values(ascending=False).round(4).to_dict(),
}
(OUTPUT_DIR / "tom_tat_ket_qua.json").write_text(
    json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

print("\nHoàn tất. Toàn bộ kết quả nằm trong thư mục:", OUTPUT_DIR.resolve())
