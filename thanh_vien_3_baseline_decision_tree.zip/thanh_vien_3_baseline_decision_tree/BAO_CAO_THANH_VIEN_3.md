# Phần báo cáo — Thành viên 3: Baseline & Decision Tree

> Phần viết sẵn để ghép vào báo cáo chung của nhóm. Các hình được tham chiếu nằm
> trong thư mục `outputs_thanh_vien_3/`.

## 1. Chuẩn bị và tách dữ liệu

Bộ dữ liệu gồm 395 sinh viên với 4 đặc trưng số (`study_hours`,
`attendance_rate`, `midterm_score`, `assignments_submitted`) và nhãn nhị phân
`passed`. Dữ liệu không có giá trị thiếu.

Phân bố nhãn bị lệch: 265 sinh viên Đậu (67.1%) và 130 sinh viên Rớt (32.9%).
Độ lệch này chi phối hai quyết định về sau: cách chia dữ liệu và cách chọn chỉ số
đánh giá.

Có 109 dòng trùng lặp hoàn toàn. Nhóm quyết định **giữ lại** các dòng này, vì
`study_hours` và `assignments_submitted` chỉ nhận 4 giá trị rời rạc nên việc
nhiều sinh viên khác nhau có cùng hồ sơ là bình thường, không phải lỗi nhập liệu.

Dữ liệu được chia theo tỷ lệ 80/20:

```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42)
```

Kết quả: Train 316 mẫu, Test 79 mẫu, cả hai đều giữ tỷ lệ Đậu 67.1%. Tham số
`stratify=y` là bắt buộc ở đây: tập Test chỉ có 79 mẫu nên nếu chia ngẫu nhiên
thuần, tỷ lệ hai lớp có thể lệch đáng kể và làm kết quả đánh giá mất tin cậy.
Tham số `random_state=42` bảo đảm mọi thành viên tái lập được cùng một cách chia.

Tập Test chỉ được sử dụng **một lần duy nhất** ở bước đánh giá cuối cùng; toàn bộ
việc chọn siêu tham số thực hiện bằng cross-validation trên tập Train.

## 2. Mô hình Baseline

Baseline là mô hình luôn dự đoán lớp chiếm đa số của tập Train, ở đây là lớp Đậu.
Mô hình này đóng vai trò **mức sàn**: mọi mô hình học máy phải vượt qua nó thì
mới chứng minh được rằng nó thực sự học được thông tin từ các đặc trưng.

Nhóm cài đặt Baseline theo hai cách và kiểm tra chúng cho kết quả trùng khớp:
tự viết bằng `y_train.mode()` để thể hiện rõ bản chất, và dùng
`DummyClassifier(strategy="most_frequent")` của scikit-learn.

Kết quả trên tập Test: Accuracy 0.671, nhưng Recall của lớp Rớt bằng 0,
F1-macro chỉ 0.402 và ROC-AUC bằng 0.500. Nói cách khác, mô hình không phát hiện
được một sinh viên có nguy cơ rớt nào. Đây chính là minh chứng cho thấy Accuracy
là chỉ số gây hiểu nhầm trên dữ liệu lệch lớp; vì vậy nhóm chọn **F1-macro** làm
tiêu chí chính khi so sánh và tinh chỉnh mô hình.

## 3. Mô hình Decision Tree

**Cây không giới hạn.** Cây mặc định (không ràng buộc độ sâu) phát triển tới 11
tầng và 62 lá, đạt Accuracy 0.946 trên Train nhưng chỉ 0.785 trên Test. Khoảng
cách lớn giữa hai con số là dấu hiệu rõ ràng của overfitting: cây đã học thuộc
nhiễu trong dữ liệu huấn luyện. Hình `do_sau_vs_accuracy.png` minh họa hiện tượng
này — Accuracy trên Train tăng đều theo độ sâu trong khi Accuracy trên Test dao
động và không cải thiện.

**Tinh chỉnh siêu tham số.** Nhóm dùng `GridSearchCV` với 5-fold Stratified
Cross-Validation, chấm điểm bằng F1-macro, thực hiện hoàn toàn trên tập Train.
Không gian tìm kiếm gồm `max_depth` (2–8), `min_samples_leaf` (1, 5, 10, 20),
`criterion` (gini / entropy) và `class_weight` (None / balanced).

Cấu hình đạt điểm CV cao nhất là cây sâu 8 tầng với 28 lá (F1-macro 0.862 ±
0.017). Tuy nhiên nhóm áp dụng thêm **quy tắc một độ lệch chuẩn** (one-standard-
error rule): chọn cấu hình đơn giản nhất có điểm CV không thấp hơn cấu hình tốt
nhất quá một độ lệch chuẩn. Kết quả là cây `entropy, max_depth=4,
min_samples_leaf=20` với F1-macro CV 0.848. Lý do của lựa chọn này gồm hai phần:
với chỉ 316 mẫu huấn luyện, chênh lệch 0.014 giữa hai cấu hình nằm trong ngưỡng
nhiễu thống kê; và cây 8 lá dễ diễn giải hơn hẳn cây 28 lá, điều quan trọng với
một mô hình mà giá trị chính nằm ở khả năng giải thích.

## 4. Kết quả và so sánh

| Mô hình | Accuracy | Precision | Recall | F1 | F1-macro | ROC-AUC |
|---|---|---|---|---|---|---|
| Baseline (Majority) | 0.671 | 0.671 | 1.000 | 0.803 | 0.402 | 0.500 |
| Decision Tree (không giới hạn) | 0.785 | 0.891 | 0.774 | 0.828 | 0.770 | 0.813 |
| **Decision Tree (đã tinh chỉnh)** | **0.797** | **0.911** | 0.774 | **0.837** | **0.785** | **0.908** |

Decision Tree tinh chỉnh vượt Baseline 12.7 điểm phần trăm về Accuracy. Khác biệt
có ý nghĩa thực tiễn hơn nằm ở lớp thiểu số: trong 26 sinh viên rớt của tập Test,
Baseline không phát hiện được trường hợp nào, còn Decision Tree phát hiện được 22
trường hợp (Recall lớp Rớt = 0.846). Với bài toán cảnh báo sớm sinh viên có nguy
cơ trượt môn, đây mới là con số quan trọng. ROC-AUC tăng từ 0.500 lên 0.908 cũng
xác nhận mô hình thực sự phân biệt được hai lớp. Xem thêm
`ma_tran_nham_lan.png` và `so_sanh_chi_so.png`.

**Độ quan trọng của đặc trưng** (hình `do_quan_trong_dac_trung.png`):

| Đặc trưng | Độ quan trọng |
|---|---|
| Điểm giữa kỳ | 0.89 |
| Tỷ lệ chuyên cần | 0.09 |
| Giờ tự học | 0.02 |
| Số bài tập đã nộp | 0.00 |

Điểm giữa kỳ áp đảo các đặc trưng còn lại — kết quả hợp lý về mặt trực giác, vì
đây là đánh giá học thuật trực tiếp nhất trong bốn biến.

## 5. Diễn giải sơ đồ cây quyết định

Sơ đồ cây được xuất ở ba dạng: `so_do_cay_graphviz.png` (nét nhất, dùng cho báo
cáo và slide), `so_do_cay_quyet_dinh.png` (vẽ bằng matplotlib) và
`luat_cay_quyet_dinh.txt` (các luật dạng văn bản).

Mỗi ô trong sơ đồ hiển thị điều kiện chia, entropy, số mẫu, phân bố `[Rớt, Đậu]`
và lớp dự đoán. Màu cam biểu thị lớp Rớt, màu xanh biểu thị lớp Đậu; màu càng đậm
thì nút càng thuần.

Các luật chính rút ra được:

- **Điểm giữa kỳ > 6.25** → Đậu. Nhánh này gom 102 mẫu train và cả 102 đều đậu.
- **Điểm giữa kỳ trong khoảng 5.25 – 6.25** → Đậu (57/61 mẫu).
- **Điểm giữa kỳ ≤ 3.75** → Rớt (51/56 mẫu). Nếu thêm điều kiện giờ tự học ≤ 3
  thì nhánh hoàn toàn thuần: 21/21 mẫu đều rớt.
- **Điểm giữa kỳ trong khoảng 3.75 – 5.25** là vùng không chắc chắn; tại đây cây
  dựa thêm vào tỷ lệ chuyên cần để phân loại.

**Một điểm bất thường cần thảo luận.** Trong vùng điểm trung bình nói trên, nhóm
sinh viên có tỷ lệ chuyên cần trên 88% lại bị dự đoán là Rớt (24 rớt so với 17
đậu) — kết quả đi ngược trực giác thông thường. Cần lưu ý nút này có entropy
0.979, tức phân bố gần như 50/50, nên nó phản ánh sự không chắc chắn của mô hình
hơn là một quy luật thực sự. Nhiều khả năng đây là đặc thù của bộ dữ liệu, chẳng
hạn sinh viên bỏ thi nên không bị ghi nhận vắng học. Không nên diễn giải nhánh
này thành kết luận "đi học đầy đủ thì rớt".

## 6. Hạn chế và hướng mở rộng

Tập Test chỉ có 79 mẫu nên sai số ước lượng các chỉ số còn khá lớn; chênh lệch
vài phần trăm giữa các mô hình chưa đủ cơ sở để khẳng định mô hình nào tốt hơn.
Bên cạnh đó, một cây quyết định đơn lẻ vốn nhạy cảm với thay đổi nhỏ của dữ liệu
huấn luyện.

Hướng mở rộng cho nhóm: thử các mô hình ensemble như Random Forest hoặc Gradient
Boosting để tăng độ ổn định, đánh giá bằng repeated cross-validation thay vì một
lần chia Train/Test duy nhất, và cân nhắc điều chỉnh ngưỡng quyết định nếu mục
tiêu thực tế là ưu tiên phát hiện sinh viên có nguy cơ rớt (tăng Recall lớp Rớt,
chấp nhận giảm Precision).
